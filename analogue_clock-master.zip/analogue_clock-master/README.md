# analogue clock

An analogue clock that uses JavaScript and the Canvas Web API
